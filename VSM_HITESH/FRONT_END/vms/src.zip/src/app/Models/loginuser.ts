export interface Loginuser 
{
    userNameOrEmail:string;
    userPassword:string;
    userRole:string;
}
