import { Component } from '@angular/core';

@Component({
  selector: 'app-vehicleunderservice',
  templateUrl: './vehicleunderservice.component.html',
  styleUrls: ['./vehicleunderservice.component.css']
})
export class VehicleunderserviceComponent {

}
