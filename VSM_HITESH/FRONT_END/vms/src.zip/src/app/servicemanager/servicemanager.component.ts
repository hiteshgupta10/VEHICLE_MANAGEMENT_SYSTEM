import { Component } from '@angular/core';

@Component({
  selector: 'app-servicemanager',
  templateUrl: './servicemanager.component.html',
  styleUrls: ['./servicemanager.component.css']
})
export class ServicemanagerComponent {

}
