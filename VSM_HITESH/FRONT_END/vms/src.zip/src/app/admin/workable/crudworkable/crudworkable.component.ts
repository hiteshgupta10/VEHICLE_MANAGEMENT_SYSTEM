import { Component } from '@angular/core';

@Component({
  selector: 'app-crudworkable',
  templateUrl: './crudworkable.component.html',
  styleUrls: ['./crudworkable.component.css']
})
export class CrudworkableComponent {

}
