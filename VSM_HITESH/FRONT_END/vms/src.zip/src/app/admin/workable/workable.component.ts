import { Component } from '@angular/core';

@Component({
  selector: 'app-workable',
  templateUrl: './workable.component.html',
  styleUrls: ['./workable.component.css']
})
export class WorkableComponent {

}
