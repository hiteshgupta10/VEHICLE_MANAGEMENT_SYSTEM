import { Component } from '@angular/core';

@Component({
  selector: 'app-allworkable',
  templateUrl: './allworkable.component.html',
  styleUrls: ['./allworkable.component.css']
})
export class AllworkableComponent {

}
