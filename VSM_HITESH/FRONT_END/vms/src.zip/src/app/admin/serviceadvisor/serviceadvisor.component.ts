import { Component } from '@angular/core';

@Component({
  selector: 'app-serviceadvisor',
  templateUrl: './serviceadvisor.component.html',
  styleUrls: ['./serviceadvisor.component.css']
})
export class ServiceadvisorComponent {

}
